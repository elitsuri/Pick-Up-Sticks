#pragma once
#include <fstream>
#include <string>
class File
{
public:
	File();
	void SetFile();//ctor
	bool HaveFile()const;//retun the boolain for have file or not
	std::string GetLine();//read line from the text
	void CloseFile();//colse the file in safe mod
	void ChateExcp(std::exception& e);//print msg
	int GetCountLine()const { return m_CounterLine; };
	~File();
private:
	std::ifstream m_FileRead;//for read from the user the file comand
	int m_CounterLine=0;//count the line form the file
	bool m_HaveFile = false;//boolain for know if we have file or not
	std::string m_Lastinput;//save the last read from file
	int m_OkLine = 0;//count the not empty files
};

