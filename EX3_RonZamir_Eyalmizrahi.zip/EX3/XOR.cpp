#include "XOR.h"
const int FIRST = 0;
const int SEC = 1;
bool XOR::Eval(const  std::vector< bool >&NumFevel)
{
	
	bool g;
	g = (NumFevel[FIRST] ^ NumFevel[SEC]);
	return  (NumFevel[FIRST] ^ NumFevel[SEC]);//return input1 XOR(logic comnd) input 2
}
XOR::~XOR()
{
}
