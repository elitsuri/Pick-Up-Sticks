#pragma once
#include <string.h>
#include <string>
#include <vector>
#include <iostream>
class Gate//abstart calss of the gate
{
public:
	Gate();
	virtual	void show()=0;//show the name of the gate and the number of input
		virtual	bool Eval(const  std::vector< bool >&NumFevel) = 0;//calculate the gate action on input
		virtual	void Table();//calcalte the true table of the gate 
		virtual	void PrintTable();//print the true table
		virtual size_t Pow(int a, int b) ;//help fun' for calcalte the pow a mul himself b times
		virtual	int GetNumOfInput()const { return m_NumberInput; };//return the number of input the gate need
		virtual void SetGataEx(const  std::vector< bool >&NumFevel);
	~Gate();
protected:
	std::string m_NameOfGate;//save the name of the gate
	int m_NumberInput;//var for save the number of input the gate need
	std::vector<std::vector < bool > >m_Table;//save the true table
	bool m_HaveTable = false;//if we have the table or not
};

