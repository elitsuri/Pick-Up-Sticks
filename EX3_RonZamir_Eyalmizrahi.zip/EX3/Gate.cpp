#include "Gate.h"

Gate::Gate()
{
}
//=============================================================
void Gate::Table()
{
	//if we calculate the table befor we have this and
	// dont need to calcalte this agin
	if (m_HaveTable)
	{
		PrintTable();
		return;
	}

	//start of the calcalte
	int c;
	//we need to cahnge the size of the vecotr to bigger
	m_Table.resize(size_t(Pow(2, m_NumberInput)));
	c = int(Pow(2, m_NumberInput));

	for (int index = 0; index < m_Table.size(); index++)
		m_Table[index].resize(m_NumberInput);
	int mid, temp_NumberInput = m_NumberInput, temp, row, col, check;

	for (int col = 0; col <m_NumberInput; col++)
	{
		temp = 0;
		check = (Pow(2, temp_NumberInput));
		mid = check / 2;
		for (int row = 0; row <Pow(2, m_NumberInput); row++)
		{
			if ((temp % check) < mid)
				m_Table[row][col] = 0;
			else
				m_Table[row][col] = 1;
			temp++;
		}
		temp_NumberInput--;
	}
	//calcalte the resulat cal
	for (size_t col = 0; col < m_Table.size(); col++)
		m_Table[col].push_back(Eval(m_Table[col]));

	m_HaveTable = true;

	PrintTable();//print the true table
	
}
//=============================================================
void Gate::PrintTable()
{
	show();//show the gate shows
	std::cout << " Truth Table: \n";
	std::cout << " input1 | input2 | result |\n";
	std::cout << "====================\n";
	//loop for print the values of the true table
	for (size_t row = 0; row < m_Table.size(); row++)
	{
		size_t col = 0;
		for (col = 0; col < m_Table[row].size() - 1; col++)
		{
			std::cout << "|" << m_Table[row][col];
			std::cout << "  ";
		}
		std::cout << "|" << m_Table[row][col];
		std::cout << "\n";
		std::cout << "====================\n";
	}
}
//=============================================================
//function get number a this is the base and mul it number  b times 
//return the resulat
size_t Gate::Pow(int a, int b)
{
	int temp = a;
	for (int i = b-1; i != 0; i--)
		a *= temp;
	return size_t(a);//return the size of we need for the table vecoter
}
//=============================================================
void Gate::SetGataEx(const std::vector<bool>& NumFevel)
{
	if (NumFevel.size() < m_NumberInput)
		throw (std::length_error("the input for eval is lees then the gate needs \n"));
}
//=============================================================
Gate::~Gate()
{
}
//=============================================================