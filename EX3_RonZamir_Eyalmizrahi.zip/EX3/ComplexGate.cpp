#include "ComplexGate.h"


ComplexGate::ComplexGate(std::shared_ptr<Gate>Gate1, std::shared_ptr<Gate>Gate2)
{
	
	m_HaveTable = false;//rest the var
	m_NumberInput = 0;
	m_MyGate.push_back(Gate1);
	m_NumberInput += Gate1->GetNumOfInput();
	m_MyGate.push_back(Gate2);
	m_NumberInput += Gate2->GetNumOfInput();
	m_NumberInput--;//the calculate of input for complex gates
}

void ComplexGate::show()
{
	for (size_t index = 0; index < m_MyGate.size(); index++)
	{ 
		m_MyGate[index]->show();//show Polymorphism use the show of "simple gates"
		if(index<m_MyGate.size()-1)
		std::cout << "->";
		
	}
	std::cout << " ("<< m_NumberInput<<" Inputs)";
}

bool ComplexGate::Eval(const  std::vector< bool >&NumFevel)
{
	std::vector <bool > temp = NumFevel;
	bool last;
	int size = 0;
	//loop for return the eval
	for (size_t index = 0; index < m_MyGate.size(); index++)
	{
		//Take the input number that needs to be assumed first we 
		//have a vector of and delete what he used it and then put in the 
		//first place the result returned from the action of the EVAL and 
		//continue this way until the gates are over
		last =m_MyGate[index]->Eval(temp);//save the answer that return from the last gate we check
		size = m_MyGate[index]->GetNumOfInput();
		temp.erase(temp.begin(),temp.begin() + size);//delate the input that we used from the input vecotr
		temp.insert(temp.begin(),last);//insert the last answer to the first palce 
	}
	return last;//return the last answer
}

ComplexGate::~ComplexGate()
{
}
