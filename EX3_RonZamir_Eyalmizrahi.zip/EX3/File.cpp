#include "File.h"
#include <iostream>
File::File()
{
	m_HaveFile = false;
}
//==================================================
//function that set the file name and check if exsiset
void File::SetFile()
{
	if(m_FileRead.is_open())
		throw (std::length_error("you have file allreay wait for its end!\n"));
	std::cout << "enter name file\n";
	std::string FileName;
		std::cin >> FileName;
	m_FileRead.open(FileName);
	std::string temp;//for cehck the tpye of the file
	for (size_t index = 0; index < FileName.size(); index++)
	{
		if (FileName[index] == '.')
		{
			int inx = 0;
			index++;
			while (index < FileName.size())
			{
				temp.push_back(FileName[index]) ;
				inx++;
				index++;
			}
		}
	}
	if(temp!="txt")//if this kind of other file
		throw (std::length_error("type of the file need to be only txt!\n"));
	if (!m_FileRead.is_open())//if this file isnot exsist
		throw (std::length_error("No such file is exist \n"));

	m_HaveFile = true;//we have file! :-)
}
//==================================================
bool File::HaveFile() const
{
	return m_HaveFile;
}
//==================================================
std::string File::GetLine()
{
	m_Lastinput = "\0";
	while (m_Lastinput == "\0")
	{
		if (m_FileRead.eof() && m_OkLine>0)//check if end of file and not empty lines
			throw (std::domain_error(" the file end in successfully!way\n"));
		if(m_FileRead.eof())//end of file and empty file
			throw (std::domain_error(" the file was empty !!\n"));
		m_Lastinput.clear();
		std::getline(m_FileRead, m_Lastinput);
		m_CounterLine++;
	}
	m_OkLine++;//count the comand line that is fine
	return m_Lastinput;
}
//==================================================
void File::CloseFile()
{
	m_HaveFile = false;
	m_FileRead.close();
	m_FileRead.clear();
	m_CounterLine = 0;
	m_OkLine = 0;
}
//==================================================
void File::ChateExcp(std::exception & e)
{
	std::cout << "Line #" << m_CounterLine << e.what()
		<< ' ' << '"' << m_Lastinput << '"' << '\n';
}
//==================================================
File::~File()
{
}
//==================================================