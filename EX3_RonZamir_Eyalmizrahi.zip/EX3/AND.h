#pragma once
#include "Gate.h"
class AND : public Gate
{
public:
	AND() { m_NumberInput = 2; m_NameOfGate = "AND"; };//c-tor rest the var for and gate
	//print the name and number of input need for eval this gate
	virtual	void show() { std::cout << "AND " << "(" << m_NumberInput << " Inputs)"; };
	virtual	bool Eval(const  std::vector< bool >& NumFevel);//return the calculate of the gate action
	~AND();
};

