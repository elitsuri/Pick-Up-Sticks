#include "OR.h"

bool OR::Eval(const  std::vector< bool >&NumFevel)
{
	
	 return (NumFevel[0] | NumFevel[1]);	//return input1 OR(logic comnd) input 2
}


OR::~OR()
{
}
