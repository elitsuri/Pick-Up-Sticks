#include "menu.h"

int main()
{
	menu m1;

	return 0;
}