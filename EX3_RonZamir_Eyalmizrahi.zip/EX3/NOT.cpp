#include "NOT.h"
const int FIRST = 0;
bool NOT::Eval(const  std::vector< bool >&NumFevel)
{
	return (!NumFevel[FIRST]);//return NOT input1 (logic comnd) 
}
NOT::~NOT()
{
}
