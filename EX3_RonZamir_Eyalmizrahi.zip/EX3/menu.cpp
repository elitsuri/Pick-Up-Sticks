﻿#include "menu.h"
#include <iostream>
#include "OR.h"
#include "XOR.h"
#include "AND.h"
#include "NOT.h"
#include "MUX.h"
#include "ComplexGate.h"
const int INDEX_EVAL = 2;
const int INDEX_COMP = 1;
//=================================================
menu::menu()
{
	//c-tor that Claims all vars the program need to stat
	SetMaxGate();
	SetGates();
	SetOption();
	Show();
	while (SelectOptions());//cal to the main fun' that Manages the interface
}
//=================================================
void menu::SetOption()
{
	//set the vecotr option
	m_options.push_back("eval");
	m_options.push_back("comp");
	m_options.push_back("table");
	m_options.push_back("del");
	m_options.push_back("exit");
	m_options.push_back("help");
	m_options.push_back("Error");
	m_options.push_back("rest");//rest the vector of the gate to the start
	m_options.push_back("resize");//change the max number of the gate
	m_options.push_back("read");//read from file
}
//=================================================
int menu::CheckCmd()
{
	//check if we have this option if we have return the chose
	//else return eror
	std::string input = MakeLineInVectorString();
	for (size_t index = 0; index < m_options.size(); index++)
		if (m_options[index].compare(input) == 0) {
			return (index);
		}
	return eror;
}
//=================================================
//main function that mange the chose of the user
bool menu::SelectOptions()
{
	//the main loop that Manages the interface
	//do switch on the comnd the user chose 
	try//try to make some command if will we trhow we catch it dwon
	{
		switch (CheckCmd())
		{
		case eval:
		{
			CalNumInput();//take input to bool vector for calculate the eval of the gate
			m_MyGate[m_IndexGate]->SetGataEx(m_NumFevel);
			m_MyGate[m_IndexGate]->show();
			std::cout << "Result: " << m_MyGate[m_IndexGate]->Eval(m_NumFevel) << '\n';
			Show();//show the new list
			break;
		}
		case comp:
		{
			SetNumFcomp();//do comp in this fun'
			break;
		}
		case table:
		{
			SetIndexGate();//get the index of the gate the user want to delete
			int i = m_IndexGate;	 //chaek if this index is in the RANGE of the vector size
			m_MyGate[m_IndexGate]->Table();//show table
			Show();//show the new list
			break;
		}
		case del:
		{
			SetIndexGate();//get the index of the gate the user want to delete
			m_MyGate.erase(m_MyGate.begin() + m_IndexGate);
			Show();//show the new list
			break;
		}
		case quit:
		{
			std::cout << "goodbye!\n";
			return false;
			break;
		}
		case help:
		{
			//std::cout << m_options[help];
			PrintHelp();
			break;
		}
		case eror:
		{
			std::cout << m_options[eror] << '\n';
			break;
		}
		case rest:
		{
			m_MyGate.clear();
			SetGates();
			Show();
			break;
		}
		case resize:
		{
			ChangeMax();//call the function the make this command
			Show();
			break;
		}
		case read:
		{
			ReadCom();//call the function the make this command
			break;
		}
		default:
			break;
		}
	}
	//catch the trhow here and print what was the eror
	catch (std::length_error & e)
	{
		std::cout << e.what();
		Show();//
	}
	catch (std::invalid_argument & e)
	{//Line #3 has invalid line “comp 0 t”
		m_File.ChateExcp(e);
		ErorInText();
		Show();//
	}
	catch (std::domain_error & e)
	{
		std::cout <<e.what();
		m_File.CloseFile();
	}
	return true;
}
//=========================================================
void menu::PrintHelp()
{
	std::cout << "Following is the list of the available commands:\n"
		<< "- eval <gate index> <param1 param2 ...> \n"
		<< "- evaluates gate no. x with param1 param2 ... etc.\n "
		<< "- comp <gate1 index> <gate2 index> -composites gate no.\n"
		<< " 1 with gate no. 2 and adds\n"
		<< " it to the list of the gates\n"
		<< "- table <gate index> -display the truth table of the selected gate\n"
		<< "- del <gate index> -delete the selected gate from the list\n"
		<< "- exit - greetings the user and closes the program\n"
		<< "- help - shows this manu again with the list of the gates\n"
		<< "- rest-now buttun that rest the vector of gate to starting position\n";
}
//=========================================================
void menu::PrintMsg()
{
	std::cout << "= == == == == == == == == == == == == == == == == == ==\n"
		<< "Please enter command from the list... (help for command list)\n";
}
//=========================================================
void menu::CalNumInput()
{
	m_NumFevel.clear();//clear the vector to new input for the eval
	if (m_input.size() < 2)//check if we have 2 input min
		return;
	CheckLineInput(INDEX_EVAL);
	SetIndexGate();//get the index of the gate
}
//=========================================================
void menu::SetIndexGate()
{
	m_IndexGate = -1;//rest the var for new secltion;
	if (m_input.size() > 1)
		if (!CheckStringOfDigits(m_input[1]))//if this not digit trhow excptions 
		{
			if (m_File.HaveFile())
				throw (std::invalid_argument(" invalid line "));
			throw (std::length_error("wrong input enter gata index (only didgit) \n"));
		}
	m_IndexGate = std::stoi(m_input[1]);
	if (m_IndexGate >= m_MyGate.size() || m_IndexGate == -1)//if this input not good
	{
		if (m_File.HaveFile())
			throw (std::invalid_argument(" invalid line "));
		throw (std::length_error("this index for the gate vector dont Exists \n"));
	}
}
//=========================================================
void menu::SetGates()
{
	//set the vecotr of the defualt (satrt) gates
	m_MyGate.push_back(std::make_shared<OR>());
	m_MyGate.push_back(std::make_shared<XOR>());
	m_MyGate.push_back(std::make_shared<AND>());
	m_MyGate.push_back(std::make_shared<NOT>());
	m_MyGate.push_back(std::make_shared<MUX>());
	ChangeGateVec();
}
//=========================================================
void menu::Show()
{
	//print the list of the gates we have in the vecotr of gates

	std::cout << "List of gates: " << '(' << m_MyGate.size() << "/" << m_SaveMaxGateNumber << ")\n";
	for (size_t index = 0; index < m_MyGate.size(); index++)
	{
		std::cout << index << ": ";
		m_MyGate[index]->show();//Polymorphism
		std::cout << "\n";
	}
	PrintMsg();
}
//=========================================================
void menu::SetNumFcomp()
{
	m_NumFcomp.clear();
	if (m_MyGate.size() == m_SaveMaxGateNumber)//this will make sure the max gates number willdont be begerr that Amount
	{
		if (m_File.HaveFile())
			throw (std::invalid_argument(" invalid line "));
		throw (std::length_error("This could not exceed the gates assigned at the beginning of the program \n"));
	}
	if (m_input.size() != 3)//check if we have 2 input min
	{
		if (m_File.HaveFile())
			throw (std::invalid_argument(" invalid line "));
		throw (std::length_error("for comp enter 2 gates index \n"));
	}
	//convert the string to int
	CheckLineInput(INDEX_COMP);
	//check if this fine iinput
	if (m_NumFcomp[0] >= m_MyGate.size() || m_NumFcomp[1] >= m_MyGate.size())
	{
		if (m_File.HaveFile())
			throw (std::invalid_argument(" invalid line "));
		throw (std::length_error("the gates index is wrong! \n"));
	}
	//make the comp
	m_MyGate.emplace_back(std::make_shared<ComplexGate>
		(m_MyGate[m_NumFcomp[0]], m_MyGate[m_NumFcomp[1]]));
	m_MyGate[m_IndexGate]->show();
	Show();
}
//=========================================================
std::string menu::MakeLineInVectorString()
{
	m_input.clear();//clear for new input;
	m_Lastinput.clear();
	if (!m_File.HaveFile())//dont command read
		std::getline(std::cin, m_Lastinput);//read line from user
	else
	{
		m_Lastinput = m_File.GetLine();
	}
	if (m_Lastinput.size() == 0)//case of empty line
	{
		std::cin.clear();
		return(m_options[eror]);
	}

	std::string temp;
	bool check = false;
	//loop that run over the line input
	for (size_t index = 0; index < m_Lastinput.size(); index++)
	{
		if (m_Lastinput[index] == '\n')
			break;

		if (m_Lastinput[index] != ' ')//check if this end of the word/num
		{
			temp.push_back(m_Lastinput[index]);
			check = true;
		}
		else {
			if (check)
				m_input.push_back(temp);
			temp.clear();
			check = false;
		}
	}
	if (check)
		m_input.push_back(temp);

	return  (m_input[0]);
}
//================================================
//input:string
//output:ture if only digits else false
//check if string is only digits
bool menu::CheckStringOfDigits(std::string Tocheck)
{
	for (size_t i = 0; i < Tocheck.size(); i++)
		if (!isdigit(Tocheck[i]))
			return false;

	return true;
}
//================================================
void menu::SetMaxGate()//set the seclection of the max gate size
{
	std::cout << "hey enter number of max gate you need \n";
	m_SaveMaxGateNumber = ReadInt();
}
//=========================================================
//function resize the vector by removed the gates that go over the max amount we can
void menu::ChangeGateVec()
{
	if (m_SaveMaxGateNumber < m_MyGate.size())
		while (m_SaveMaxGateNumber != m_MyGate.size())
			m_MyGate.pop_back();
}
//=========================================================
//function that cahnge the max amount of the vector of gates and make sure the uesr is sure about him chose
void menu::ChangeMax()
{
	int new_size = ReadInt();
	if (new_size < m_MyGate.size())
	{
		std::cout << m_MyGate.size() << " gates are existing now.\n";
		std::cout << "Press Y to delete the last " <<
			m_MyGate.size() - new_size << " gates or N to cancel\n";
		if (ReadChar('Y', 'N') == 'Y')
		{
			m_SaveMaxGateNumber = new_size;
			ChangeGateVec();
			std::cout << "The size of the list reset to " << new_size << " successfully!\n";
		}
	}
	else
		m_SaveMaxGateNumber = new_size;
	Show();
}
//=========================================================
//fuction that read int and make sure its int and not somthing else
int menu::ReadInt()
{
	std::string num;
	if (m_input.size() >= 2)
		num = m_input[1];
	else
	{
		std::cin >> num;
	}
	while (1)//while the user insert the corcect size of max gate
	{
		if (CheckStringOfDigits(num) && std::stoi(num) >= 1)
		{
			int nn = 1;
			if (m_input.size()<2)//case its from cin and not from m_input
			std::cin.ignore(INT_MAX, '\n');//clean the buffer
			std::cin.clear();//clear the std cin
			return(std::stoi(num));
		}
		else
		{ 
			std::cout << "please enter correct number of gate that you need (min 1 gate)\n";
			std::cin >> num;
		}
	}
}
//=========================================================
char menu::ReadChar(char a, char b)
{
	while (1)//while the user insert the corcect size of max gate
	{
		std::string str;
		std::cin >> str;//to check if this digits
		if (str.size() == 1 && (str[0] == a || str[0] == b))
		{
			std::cin.clear();//clear the std cin
			std::cin.ignore(INT_MAX, '\n');//clean the buffer
			return(str[0]);
		}
		else
			std::cout << "please enter only " << a << " / " << b << " \n";
		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');//clean the buffer
	}
}
//=========================================================
//function for the read comannd
void menu::ReadCom()
{
	m_File.SetFile();
}
//=========================================================
void menu::ErorInText()//function for if we have eror in line form the text
{
	std::cout << "Press S to skip this line or E to exit from this file\n";
	char c = ReadChar('S', 'E');
	if (c == 'E')
		m_File.CloseFile();//the user want to close the file
	//else if he ensert s then skip this line
}
//=========================================================
void menu::CheckLineInput(size_t index)
{
	//check if the line is fine all the input is ok
		while(index < m_input.size())
	{
		if (!CheckStringOfDigits(m_input[index]))
		{
			if (m_File.HaveFile())
				throw (std::invalid_argument(" invalid line "));
			throw (std::length_error("wrong input enter gata index only digits \n"));
		}
		if(m_input[0]=="comp")
		m_NumFcomp.push_back(std::stoi(m_input[index]));
		else
		{
			if (std::stoi(m_input[index]) != 0 && std::stoi(m_input[index]) != 1)
			{
				if (m_File.HaveFile())
					throw (std::invalid_argument(" invalid line "));
				throw (std::length_error("the input for eval is only digits zero and  one \n"));
			}
			m_NumFevel.push_back(std::stoi(m_input[index]));
		}
		index++;
	}
}
//=========================================================
menu::~menu()
{
}
