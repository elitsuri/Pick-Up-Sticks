#pragma once
#include "Gate.h"
class NOT : public Gate
{
public:
	NOT() { m_NumberInput = 1; m_NameOfGate = "NOT"; };//c-tor rest the var for and gate
	//print the name and number of input need for eval this gate
	virtual	void show() { std::cout << "NOT " << "(" << m_NumberInput << " Inputs)"; };
	virtual	bool Eval(const  std::vector< bool >&NumFevel);//return the calculate of the gate action

	~NOT();
};

