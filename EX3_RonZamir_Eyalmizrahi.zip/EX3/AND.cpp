#include "AND.h"

bool AND::Eval(const  std::vector< bool >&NumFevel)
{
	return (NumFevel[0] & NumFevel[1]);//return input1 and(logic comnd) input 2
}
AND::~AND()
{
}
