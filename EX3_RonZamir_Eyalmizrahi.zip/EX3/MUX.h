#pragma once
#include "Gate.h"
class MUX : public Gate
{
public:
	MUX() { m_NumberInput = 3; m_NameOfGate = "MUX";};//c-tor rest the var for and gate
	//print the name and number of input need for eval this gate
	virtual	void show() { std::cout << "MUX " << "(" << m_NumberInput << " Inputs)"; };
	virtual bool Eval(const  std::vector< bool >&NumFevel);//return the calculate of the gate action
	
	~MUX();
};

