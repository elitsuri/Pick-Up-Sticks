#include "MUX.h"

bool MUX::Eval(const  std::vector< bool >&NumFevel)
{
	//return mux of input1  input 2 input 3 
	return((NumFevel[0] * !NumFevel[2]) + (NumFevel[1] * NumFevel[2]));
}

MUX::~MUX()
{
}
