#pragma once
#include "Gate.h"
class XOR : public Gate
{
public:
	XOR() { m_NumberInput = 2; m_NameOfGate = "XOR"; };//c-tor rest the var for and gate
	//print the name and number of input need for eval this gate
	virtual	void show() { std::cout << "XOR " << "(" << m_NumberInput << " Inputs)"; };
	virtual	bool Eval(const  std::vector< bool >&NumFevel);//return the calculate of the gate action
	
	~XOR();
};

