#pragma once
#include "Gate.h"
class OR :public Gate
{
public:
	OR() { m_NumberInput = 2; m_NameOfGate = "OR";};//c-tor rest the var for and gate
	//print the name and number of input need for eval this gate
	virtual	void show() { std::cout << "OR " << "(" << m_NumberInput << " Inputs)"; };
	virtual	bool Eval(const  std::vector< bool >&NumFevel) ;//return the calculate of the gate action

	~OR();
};

