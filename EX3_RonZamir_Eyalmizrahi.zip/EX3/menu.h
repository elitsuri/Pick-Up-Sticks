#pragma once
enum option { eval, comp, table, del, quit, help, eror, rest, resize,read };
#include <fstream>
#include <string.h>
#include <string>
#include <vector>
#include <memory>
#include "Gate.h"
#include "File.h"
class menu
{
public:
	menu();//c-tor that Claims all vars the program need to stat
	void SetOption();//set the word that user cna coshe from
	int CheckCmd();//check the first index in the input from the user to select the comnd
	bool SelectOptions();//switch case on the comnd thte usee was chosen
	void PrintHelp();//the masge of the help comnd(print string witch the text of help)
	void PrintMsg();//print the txet of place select acomnd for the start
	void CalNumInput();//fun' for read the inpput for eval comnd 
	void SetIndexGate();//set the index in the vector of the gate as per the user was Wanted
	void SetGates();//insert the simpli gates (start defoalte gate) in the main vector gate
	void Show();//print the list of the gate that we have in the vector of gate
	void SetNumFcomp();//read the number from the input for comp comnd
	std::string MakeLineInVectorString();//fun' that get the line from the user and make it vector of string
	bool CheckStringOfDigits(std::string Tocheck);//check if string is only digits
	void SetMaxGate();//for read the max gate number from the user
	void ChangeGateVec();//remove the gates that over the max size of number gates
	void ChangeMax();//to chagne the max gate number
	int ReadInt();//read corect int from the user
	char ReadChar(char a, char b);//function the read cahr if somthing rwong its throw expction
	void ReadCom();//function for the comannnd read from file
	void ErorInText();//function for if we have eror in line form the text
	void CheckLineInput(size_t index);
	~menu();

private:	
std::vector	< std::string >  m_options;//for switch case(use compre from string lebary)
std::vector	< std::string >  m_input;//for save the input
std::vector	< bool > m_NumFevel;//save the input for eval comnd and the gate class use this 
std::vector	< int > m_NumFcomp;//save the 2 index for make the comp comnd
int m_IndexGate;//save the index that user cohse on the list gate
std::vector<std::shared_ptr<Gate>> m_MyGate;//the vector of the gates 
int m_SaveMaxGateNumber=10;//for the max amount of gates the user well use
std::string m_Lastinput;
File m_File;//for save the file object
};

