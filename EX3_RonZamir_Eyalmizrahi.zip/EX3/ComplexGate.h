#pragma once
#include "Gate.h"
#include <memory>
class ComplexGate : public Gate
{
public:
	ComplexGate(std::shared_ptr<Gate>, std::shared_ptr<Gate>);//get 2 shared_ptr<Gate> and make it "one gate"
	virtual	void show();//show the gate name and number of  input to calculate eval
	virtual	bool Eval(const  std::vector< bool >&NumFevel);//return the logic action of the gates insed the vecotr
	~ComplexGate();
private:
	std::vector<std::shared_ptr<Gate>> m_MyGate;//save the pointr to the gate we insert
	
};

