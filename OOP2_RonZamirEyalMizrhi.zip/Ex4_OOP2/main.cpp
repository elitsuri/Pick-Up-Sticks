#include "start_menu.h" 
int main()
{
	start_menu a;
	return 0;
 }