#pragma once
#include <iostream>
#include <memory>
#include <cctype>
#include <vector>
#include "Validator.h"
#include "BaseField.h"
//template calss for the Field
template< typename T >

class Field:public BaseField
{
public:
	Field(const std::string& NameField);//c-tor get name
	//Added a locator verification function
	void addValidator(Validator<T>* Toinsert) { m_MyValidator.push_back(Toinsert);};
	//A field checking function to be entered
	bool ItOK()const ;
	//function to insert data
	void SetNewData();
	//function to get varian T of private
	T GetVar()const { return m_Var; };
	//function print of the ruselt
	std::ostream & Print(std::ostream & os) const;
//	Field update function
	void ChangeFiled();
	~Field() {};
protected:
	T m_Var;
	std::vector<Validator<T>* > m_MyValidator;
};
//=====================================================
////c-tor get name
//============================================
template<class T>
Field<T>::Field(const std::string& NameField)//c-tor get name
{
	m_FieldName = NameField;//which valditor now
	std::cout << "-------------------------\n";
	std::cout << m_FieldName << " : ";//print this 
	std::cin >> m_Var; //get from the user the info
	std::cout << "-------------------------\n";
	std::cout << '\n';
}
//=====================================================
////A field checking function to be entered
//=====================================================
template<typename T>
 bool Field<T>::ItOK() const
{
	 //while on vec to check the info
	 for (size_t i = 0;i < m_MyValidator.size();i++)
		 if (!m_MyValidator[i]->CheckFelid(m_Var))
		 { 
			 return false;
		 }
	return true;
}
 //=====================================================
 //function to insert data
 //=====================================================
 template<typename T>
 inline void Field<T>::SetNewData()
 {
	 //if not good go to update the field that need
	 if (!ItOK())
	 {
		 ChangeFiled();//func to change just the info that no good
	 }
 }
 //=====================================================
 //function print of the ruselt
 //=====================================================
 template<typename T>
 inline std::ostream & Field<T>::Print(std::ostream & os) const
 {
	 //Printout according to exercise instructions
	 std::cout << "-------------------------\n";
	  os << m_FieldName; 
	  os << " = " << m_Var << " ";
	  for (size_t i = 0; i < m_MyValidator.size(); i++)
	  { 
		  if(!ItOK())
		  m_MyValidator[i]->Print(os);
	  }
	  std::cout << "\n-------------------------\n";
	  return os;
 }
 //=====================================================
 //	Field update function
 //=====================================================
 template<typename T>
 inline void Field<T>::ChangeFiled()
 {
	 std::cout << "-------------------------\n";
	 std::cout << m_FieldName << " : ";
	 std::cin >> m_Var;
	 std::cout << "-------------------------\n";
	 std::cout << '\n';
 }

