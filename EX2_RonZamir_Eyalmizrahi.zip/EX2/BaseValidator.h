#pragma once
#include <string>
class  BaseValidator
{
public:
	//all this base class its for the from vector to save the vlaitors
	BaseValidator() {};
	~BaseValidator() {};
	virtual bool GetAns() = 0; //virtual function for get the answer of the Validator(use in the form)
	//print function wirte on the ostream the text masage of the validtor
	std::ostream & Print(std::ostream & os) const { os << m_StrEror; return os; }
	virtual void SetData() =0;//If the user filled in incorrect details then it changes the test
protected:
	bool m_ans = false;//to know the answer
	std::string m_StrEror;//save the masgae eror
};
