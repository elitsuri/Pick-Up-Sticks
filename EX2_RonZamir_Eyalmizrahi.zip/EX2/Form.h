#pragma once
#include <vector>
#include "BaseField.h"
#include "BaseValidator.h"
class Form
{
public:
Form() {};
//function that add to the m_fields vec the fileds 
void addField(BaseField* ToiNsert);
//function that add to the Validator vec the fileds 
void addValidator(BaseValidator* ToiNsert) { m_Validators.push_back(ToiNsert); };
//Function switch on form to fill and fix where necessary
void fillForm();
//A function that checks if all the fields are filled with a good fill
bool validateForm();
//function that show the Fields if the Fields is dont good it will be eror near this
std::ostream & ShowFields(std::ostream & os)const;
////Function to display malfunctions
std::ostream & ShowValidators(std::ostream & os)const;
//d-tor
~Form() {};

private:
std::vector<BaseField *> m_fields; //vector for all the fields that we have
std::vector<BaseValidator *> m_Validators; //  vector to Validators that the info we gat is fine
};
std::ostream & operator<<(std::ostream & os, const Form& form);
