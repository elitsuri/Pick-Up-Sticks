#pragma once
template<typename T >
#include "Validator.h"
#include <string>
class RangeValidator :public  Validator < T  >
{
//===================================================================================
public:///RangeValidator to check the age of the user
	
	RangeValidator(const T & RangeMax, const T & RangeMin);//ctor
	~RangeValidator() {};///dtor
	virtual bool CheckFelid(const T & age)const override;

private:
	T m_RangeMax;//save the range max
	T m_RangeMin;//save the range min
};
//===================================================================================
template<typename T>
inline RangeValidator<T>::RangeValidator(const T & RangeMax, const T & RangeMin)
{
	//save what we got that is the range min and max for the age
		m_RangeMax = RangeMax; 
		m_RangeMin = RangeMin;
		m_StrEror = "Out of range"; //save the eror masage
}
//===================================================================================
template<typename T>
inline bool RangeValidator<T>::CheckFelid(const T & age) const
{
	//the fun that check if the age is betwin the corunt ages
		if (age<m_RangeMin && age>m_RangeMax)
			return true;
		return false;
	
}
//===================================================================================