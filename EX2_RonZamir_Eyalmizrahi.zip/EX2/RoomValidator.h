#pragma once
#include "Validator.h"
const int PAIR = 2;
const int FAMILY = 5;
template <class T, class T1, class T2>
class RoomValidator :public Validator <T>
{
//======================================================================
public:
	RoomValidator(std::string str, T* a, T1* b, T2* c);//ctor
	~RoomValidator() {}
	bool CheckFelid(const  T &t)const { return true; };
	bool GetAns();
	virtual void SetData();
private:
	std::vector < T* > m_Tvec;//to save the templates fileds we get in the ctor

};
//======================================================================
//ctor for this calss that get 3 var of tamplete calss (this will be vlaidtors)
template<class T, class T1, class T2>
inline RoomValidator<T, T1, T2>::RoomValidator(std::string str, T * a, T1 * b, T2 * c)
{
	//insert the tampleate calss T to the vector
	m_Tvec.push_back(a);
	m_Tvec.push_back(b);
	m_Tvec.push_back(c);
	//save the eror masgae
	m_StrEror = "Number of adults and children in each room don't match total number of people";
}
//======================================================================
//this function check if the data in the vec of the filed is ok 
//return ture if it matche else return false
template<class T, class T1, class T2>
inline bool RoomValidator<T, T1, T2>::GetAns()
{
	//cehck if the filed of number of pepole=number of familey room+pair rooms
	if (m_Tvec[0]->GetVar() == (m_Tvec[2]->GetVar()*FAMILY) + (m_Tvec[1]->GetVar()*PAIR))
		return true;
	return false;
}
//======================================================================
//to change the rong answer the user enter in the start of the program
template<class T, class T1, class T2>
inline void RoomValidator<T, T1, T2>::SetData()
{
	for (size_t i = 0; i < m_Tvec.size(); i++)
		m_Tvec[i]->ChangeFiled();
}
//======================================================================
