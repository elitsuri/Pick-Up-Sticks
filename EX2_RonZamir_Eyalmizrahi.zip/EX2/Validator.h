#pragma once
#include <cctype>
#include "BaseValidator.h"
template <typename T >
class Validator:public BaseValidator
{
public:
	Validator() {};
	virtual ~Validator() {}
	///virtual function that get tamplete calass T and check if this contions for the filed
	virtual bool CheckFelid(const  T &t)const = 0;//{ return false; };
	virtual bool GetAns() { return m_ans; };//return the answaer
	virtual void SetData() {}//to change the rong answer the user enter in the start of the program
	
};

