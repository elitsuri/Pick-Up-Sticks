#pragma once
template<typename T >
#include "Validator.h"
#include <string>
class NotGreaterThanValidator :public  Validator < T  >
{
//======================================================================
public:
	//ctor save the max rooms and the eror masgae
	NotGreaterThanValidator(int MAXROOMS) :m_maxrooms(MAXROOMS) 
	{ m_StrEror = "The maximum is 10 rooms "; };
//======================================================================
	~NotGreaterThanValidator() {};
	virtual bool CheckFelid(const T & ToCheck)const override;
private:
	int m_maxrooms;//save the max rooms that we have in the hotel
};
//======================================================================
template<typename T>
inline bool NotGreaterThanValidator<T>::CheckFelid(const T & ToCheck) const
{
	//check if we the user didnt inserte more rooms then the hotel have
		if (m_maxrooms >= ToCheck)
			return true;
		return false;
}
//======================================================================