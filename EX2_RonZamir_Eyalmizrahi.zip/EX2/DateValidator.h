#pragma once
template<typename T >
#include "Validator.h"
#include <string>
#include <ctime>
class DateValidator :public  Validator < T  >
{
//===============================================================
public:
	DateValidator();
	//this long masge so we break to new line and then print the eror masgeas
	std::ostream & Print(std::ostream & os) const { os <<'\n' << m_StrEror; return os; }
	~DateValidator() {};
	virtual bool CheckFelid(const T & ToCheck)const override;
private:
	//to save the data we   calcate for the corecnt year for the day the program runing 
	int m_date_day;
	int m_date_mon;
	int m_date_year;
};
//===============================================================
template<typename T>
inline DateValidator<T>::DateValidator()
{
	//find the date of today
	using clock = std::chrono::system_clock;
	auto now = clock::to_time_t(clock::now());
	std::tm calendarTime = {};
	localtime_s(&calendarTime, &now);
	m_date_day = calendarTime.tm_mday;
	m_date_mon = calendarTime.tm_mon + 1;
	m_date_year = calendarTime.tm_year + 1900;
	m_StrEror = "Thedate is already passed ";
}
//===============================================================
//function that check the date if the date he got is already passed he return false
//else return true
template<typename T>
inline bool DateValidator<T>::CheckFelid(const T & ToCheck) const
{
//cehck if this is in the range of the year and dont already passed
		T temp = ToCheck;
		temp = ToCheck % 10000;
		if (temp < m_date_year)
			return false;
		T temp_mon = (ToCheck / 10000) % 100;
		T temp_day = (((ToCheck / 10000) / 100)) % 100;
		if (temp_mon < m_date_mon)
			return false;

		if (temp_mon == m_date_mon && temp_day < m_date_day)
			return false;

		return true;
}
//===============================================================