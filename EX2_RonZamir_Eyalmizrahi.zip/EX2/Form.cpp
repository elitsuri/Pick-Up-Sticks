#include "Field.h"
#include "Form.h"
//========================================
//function that add to the m_fields vec the fileds 
//==========================================
void Form::addField(BaseField* ToiNsert)
{
	m_fields.push_back(ToiNsert);
}
//========================================
//Function switch on form to fill and fix where necessary
//========================================
void Form::fillForm()
{
	//if the input that user inside the filed was rong
	for (const auto& filed : m_fields)
		filed->SetNewData();
	//If the user needs to fix then correct the places needed
	for (const auto& Validator : m_Validators)
	{
		if(!Validator->GetAns())
		Validator->SetData();
	}
}
//=========================================
//A function that checks if all the fields are filled with a good fill
//================================
bool Form::validateForm()
{
	for (const auto& filed : m_fields)
		if (!filed->ItOK())
			return false;

	for (const auto& Validator : m_Validators)
		if (!Validator->GetAns())
			return false;

	return true;
}
//=========================================================
//function that show the Fields if the Fields is dont good it will be eror near this
//=============================================================
std::ostream & Form::ShowFields(std::ostream & os)const
{
	for (size_t i = 0; i < m_fields.size(); i++)
	{
		//show the Fields if the Fields is dont good it will be eror near this
		//if(m_fields[i]->ItOK())//
		m_fields[i]->Print(os);
	}
	return os;
}
//============================================================
//Function to display malfunctions
//==========================================================
std::ostream & Form::ShowValidators(std::ostream & os) const
{
	for (size_t i = 0; i < m_Validators.size(); i++)
	{
		//if not If the field was not filled correctly
		if(!m_Validators[i]->GetAns())
		{ 
		os << "-----------------------------\n";
		m_Validators[i]->Print(os);
		os << "-----------------------------\n";
		}
	}
	return os;
}
//==========================================
//Print function with delimiter line
//==============================================
std::ostream & operator<<(std::ostream & os, const Form& form)
{
	os << "-----------------------------\n";

	form.ShowFields(os);
	form.ShowValidators(os);

	return os;
}
//==========================================