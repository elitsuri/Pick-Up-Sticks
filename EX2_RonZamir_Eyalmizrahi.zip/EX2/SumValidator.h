#pragma once
#include "Validator.h"
template <class T, class T1, class T2>
class SumValidator :public Validator <T>
{
public:
	SumValidator(std::string str, T* a, T1* b, T2* c);
	~SumValidator() {}
	bool CheckFelid(const  T &t)const { return true; };
	virtual bool GetAns();
	virtual void SetData();
private:
	std::vector < T* > m_Tvec;
	
};
	template<class T, class T1, class T2>
	inline SumValidator<T, T1, T2>::SumValidator(std::string str, T * a, T1 * b, T2 * c)
	{
		m_Tvec.push_back(a);
		m_Tvec.push_back(b);
		m_Tvec.push_back(c);
		m_StrEror = str;
	}

	template<class T, class T1, class T2>
	inline bool SumValidator<T, T1, T2>::GetAns()
	{
		if (m_Tvec[0]->GetVar() == m_Tvec[2]->GetVar() + m_Tvec[1]->GetVar())
			return true;
		return false;
	}

	template<class T, class T1, class T2>
	inline void SumValidator<T, T1, T2>::SetData()
	{
		for (size_t i = 0; i < m_Tvec.size(); i++)
			m_Tvec[i]->ChangeFiled();
	}
	
