#pragma once
#include <string>

class BaseField
{
public:
	BaseField() {};//c-tor get name
	//virtual function abstract to funct check if data ok
	virtual bool ItOK()const=0;
	//virtual function abstract to updatae data
	virtual void SetNewData()=0;
	//d-ctor of this class
	virtual ~BaseField() {};
	//function to get private of answer of this field
	virtual bool GetAns()const { return m_ans;  };
	//virtual abstract function to print
virtual	std::ostream & Print(std::ostream & os) const = 0;
protected:
	std::string m_FieldName;//save the name of the Field
	bool m_ans = false; //private save if the answer good or not


};
	

