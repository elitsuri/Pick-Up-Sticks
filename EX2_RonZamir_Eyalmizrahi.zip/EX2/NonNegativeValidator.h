#pragma once
template<typename T >
#include "Validator.h"
#include <string>

class NonNegativeValidator :public  Validator < T  >
{
//=========================================================================
public:
	//ctor save the eror msage
	NonNegativeValidator() { m_StrEror = "Can't be negative "; };
	~NonNegativeValidator() {};
	virtual bool CheckFelid(const T & ToCheck)const override;
};
//=========================================================================
template<typename T>
inline bool NonNegativeValidator<T>::CheckFelid(const T & ToCheck) const
{
	if (ToCheck >= 0)//cehck if the filed we have is not Negative
		return true;
	return false;
}
//=========================================================================