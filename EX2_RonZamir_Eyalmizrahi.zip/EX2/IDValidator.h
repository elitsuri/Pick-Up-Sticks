#pragma once

//template<typename T >
#include "Validator.h"
#include <string>
class IDValidator :public  Validator <uint32_t>
{
public:
//===============================================================
	IDValidator() { m_StrEror = "Wrong control digit ";};//save the eror msag

	~IDValidator() {};
//===============================================================
//this function get id number and check if its corrcet and ok numer of identity card
//retrn ture if yes elae false
	virtual bool CheckFelid(const uint32_t & check_id)const override
	{
		//function that check the id 
		//if the Control digit on identity card is fine if this fine all the dada is corect
		if (check_id >= std::pow(10, 9))
			return false;

		std::uint32_t answer = check_id;

		int ins = answer % 10;

		answer /= 10;

		int t1, t2;

		int sum = 0, counter = 1;
//the main loop that make the calculate
		while (answer != 0)
		{
			t1 = answer % 10;

			answer /= 10;

			if (counter % 2 != 0)
				t1 *= 2;

			counter++;

			if (t1 > 9)
			{
				t2 = t1 % 10;
				t1 /= 10;
				t1 += t2;
			}

			sum += t1;
		}

		if ((ins + sum) % 10 == 0)
			return true;

		return false;
	}
//===============================================================
};