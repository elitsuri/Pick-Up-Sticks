#pragma once
//template<typename T >
#include "Validator.h"
#include <string>
class NoDigitValidator :public  Validator <std::string>
{
public:
//=========================================================================
	//save the eror msages
	NoDigitValidator() { m_StrEror = "Can't contain digits"; };
	
	~NoDigitValidator() {};
//=========================================================================	
	virtual bool CheckFelid(const std::string & g)const override
	{
		//check that we dont have digit in the string the function get
		for (auto t : g)
			if (isdigit(t))return false;

		return true;
	}
};
//=========================================================================